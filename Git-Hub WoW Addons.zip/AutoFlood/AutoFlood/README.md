AutoFlood
=========
AutoFlood periodically sends a single-line message in a chat channel. It's designed for advertisement for guild recruitment, crafting, in-game events...

* `/flood [on|off]` : Start / stops sending the message.
* `/floodmsg <message>` : Sets the message. Supports hyperlinks to items, spells, crafts, achievements...
* `/floodchan <channel>` : Sets the channel. Accepted values : say, guild, raid, party, bg and channel number
* `/floodrate <duration>` : Sets the period (in seconds), minimum 10
* `/floodinfo` : Displays the message and the parameters.
* `/floodhelp` : Displays this help message.

The settings are saved per character/realm.
