Changelog
=========

v1.4.6
------
* Updated for WoW patch 10.1.7 and WoW Classic patch 1.14.4.

v1.4.5
------
* Updated for WoW patch 10.1.

v1.4.4
------
* TOC bump for WoW patch 10.0.7.

v1.4.3
------
* TOC bump for WoW patch 10.0.5.
* TOC bump for WoW Classic patch 3.4.1.

v1.4.2
------
* TOC bump for WoW patch 10.0.2.

v1.4.1
------
* TOC bump for WoW patch 10.0.0.

v1.4.0
------
* Configuration is now saved character-wide instead of account-wide. #3
* Wait for the current message to be actually sent before sending the next one. #4
* Added support for instance chat (/i).
* Improved channel setting.

v1.3.3
------
* Added support for Wrath of the Lich King Classic.
* Updated for WoW Retail patch 9.2.7.

v1.3.2
------
* TOC bump for WoW 9.2, WoW BC Classic 2.5.3 and WoW Classic 1.14.2.

v1.3.1
------
* TOC bump for WoW 9.1.5.

v1.3.0
------
* Created TOCs for WoW Retail, Classic and Burning Crusade Classic.

v1.2.4
------
* Updated TOC for WoW patch 9.0.5

v1.2.3
------
* Updated TOC for WoW patch 9.0.2

v1.2.2
------
* Updated for WoW Shadowlands 9.0.1 prepatch

v1.2.1
------
* Rewritten to use MessageQueue

v1.2.1
------
* Fixed initialization issue (at last!)

v1.1
----
* Fixed minor onEvent function bug

v1.0
----
* Initial release